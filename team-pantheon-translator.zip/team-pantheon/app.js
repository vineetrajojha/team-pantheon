// app.js
let localStream;
let remoteStream;
let peerConnection;

async function startCall() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById('localVideo').srcObject = localStream;

    // Create RTCPeerConnection
    peerConnection = new RTCPeerConnection();

    // Add local stream to RTCPeerConnection
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

    // Set up event handlers for the negotiation needed and ice candidate events
    peerConnection.onnegotiationneeded = handleNegotiationNeededEvent;
    peerConnection.onicecandidate = handleIceCandidateEvent;

    // Create offer
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    // Send offer to the other peer (you would typically use a signaling server here)
    const offerMessage = { offer: offer };
    handleSignalData(offerMessage);
  } catch (error) {
    console.error('Error starting the call:', error);
  }
}

async function handleNegotiationNeededEvent() {
  try {
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    // Send the updated offer to the other peer
    const offerMessage = { offer: offer };
    handleSignalData(offerMessage);
  } catch (error) {
    console.error('Error handling negotiation needed event:', error);
  }
}

function handleIceCandidateEvent(event) {
  if (event.candidate) {
    // Send the candidate to the other peer
    const iceMessage = { ice: event.candidate };
    handleSignalData(iceMessage);
  }
}

function handleSignalData(data) {
  // Send signaling data to the other peer (you would typically use a signaling server here)
  // For simplicity, log the data to the console in this example
  console.log('Signaling data:', data);

  // In a real application, you would send the data to the other peer via a signaling server
  // For example, you might use WebSockets to exchange signaling data between peers
}

function endCall() {
  // Close the RTCPeerConnection and stop local media
  if (peerConnection) {
    peerConnection.close();
  }
  if (localStream) {
    localStream.getTracks().forEach(track => track.stop());
  }

  // Clear video elements
  document.getElementById('localVideo').srcObject = null;
  document.getElementById('remoteVideo').srcObject = null;
}