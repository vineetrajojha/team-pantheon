import cv2
from googletrans import Translator
import speech_recognition
import gtts
import playsound

vid = cv2.VideoCapture(0)
ret, frame = vid.read()

cv2.imshow('PantheonConnects', frame)


recognizer = speech_recognition.Recognizer()

with speech_recognition.Microphone() as source:
    print("Speak something...")
    voice = recognizer.listen(source)
    try:
        text = recognizer.recognize_google(voice, language='en')
        print("You said:", text)
    except speech_recognition.UnknownValueError:
        print("Sorry, I could not understand what you said.")
        text = ""

translator = Translator()
translation = translator.translate(text, dest="fr")
print("Translation:", translation.text)

converted_audio = gtts.gTTS(translation.text, lang="fr")
converted_audio.save("audio.mp3")
playsound.playsound("audio.mp3")





